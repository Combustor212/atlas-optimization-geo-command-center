import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import MGOLogo from './MGOLogo';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function MarketingHeader() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [remaining, setRemaining] = useState(294);
  const navigate = useNavigate();
  const location = useLocation();

  // Fetch remaining spots
  useEffect(() => {
    const fetchRemaining = async () => {
      try {
        const res = await fetch('/functions/betaRemaining', { cache: 'no-store' });
        const json = await res.json();
        if (Number.isFinite(json.remaining)) {
          setRemaining(json.remaining);
        }
      } catch (err) {
        console.warn('Failed to fetch waitlist count:', err);
        // Keep fallback of 294
      }
    };
    fetchRemaining();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'How It Works', path: createPageUrl('HowWorks') },
    { label: 'Plans', path: createPageUrl('pricing') },
    { label: 'AI Tools', path: createPageUrl('AITools') },
    { label: 'Support', path: createPageUrl('GetSupport') },
  ];

  const isOnBeta = location.pathname.startsWith('/beta') || location.pathname === '/Beta';

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <MGOLogo 
            linkTo="/"
            size="md"
          />

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.path}
                className="px-4 py-2 text-sm font-medium text-slate-700 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* CTA Buttons - Desktop */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Waitlist CTA */}
            <Link
              to="/beta"
              aria-label="Join the MGO Data Private Beta waitlist"
              className={cn(
                "relative inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-semibold text-sm transition-all shadow-md hover:shadow-lg",
                isOnBeta
                  ? "bg-gradient-to-r from-amber-600 to-amber-500 text-white ring-2 ring-amber-300"
                  : "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white"
              )}
            >
              <span>Waitlist</span>
              {remaining > 0 && (
                <span className="px-2 py-0.5 bg-white/90 text-amber-700 text-xs font-bold rounded-full">
                  {remaining} left
                </span>
              )}
            </Link>

            <Button
              onClick={() => navigate(createPageUrl('signin'))}
              variant="ghost"
              className="text-slate-700 hover:text-indigo-600"
            >
              Sign In
            </Button>
            <Button
              onClick={() => navigate(createPageUrl('pricing'))}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl transition-all"
            >
              Start Free Trial
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="lg:hidden overflow-hidden bg-white border-t border-slate-200"
            >
              <div className="flex flex-col gap-2 py-4">
                {/* Waitlist - Top Priority */}
                <Link
                  to="/beta"
                  onClick={() => setIsOpen(false)}
                  aria-label="Join the MGO Data Private Beta waitlist"
                  className={cn(
                    "mx-4 px-4 py-3 text-center font-bold rounded-lg transition-all shadow-md",
                    isOnBeta
                      ? "bg-gradient-to-r from-amber-600 to-amber-500 text-white ring-2 ring-amber-300"
                      : "bg-gradient-to-r from-amber-500 to-amber-600 text-white"
                  )}
                >
                  <div className="flex items-center justify-center gap-2">
                    <span>Waitlist</span>
                    {remaining > 0 && (
                      <span className="px-2 py-0.5 bg-white/90 text-amber-700 text-xs font-bold rounded-full">
                        {remaining} left
                      </span>
                    )}
                  </div>
                </Link>

                {/* Regular Nav Items */}
                {navItems.map((item) => (
                  <Link
                    key={item.label}
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className="px-4 py-3 text-left text-base font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition-colors"
                  >
                    {item.label}
                  </Link>
                ))}

                {/* Bottom CTAs */}
                <div className="flex flex-col gap-2 mt-2 pt-2 border-t border-slate-200 px-4">
                  <Button
                    onClick={() => {
                      setIsOpen(false);
                      navigate(createPageUrl('signin'));
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Sign In
                  </Button>
                  <Button
                    onClick={() => {
                      setIsOpen(false);
                      navigate(createPageUrl('pricing'));
                    }}
                    className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
                  >
                    Start Free Trial
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}