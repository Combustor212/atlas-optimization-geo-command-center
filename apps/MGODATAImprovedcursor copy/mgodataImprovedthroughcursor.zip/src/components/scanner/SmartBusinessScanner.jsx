// ============================================================================
// MGO DATA - Smart Business Scanner Component
// Complete reset - no legacy code - production ready
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Building, 
  MapPin, 
  Globe, 
  Mail, 
  Sparkles, 
  Check, 
  Loader2,
  AlertTriangle,
  Zap,
  ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// Global country list
const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Australia", "Germany", "France",
  "Spain", "Italy", "Netherlands", "Belgium", "Switzerland", "Austria",
  "Sweden", "Norway", "Denmark", "Finland", "Ireland", "Portugal", "Poland",
  "Japan", "South Korea", "Singapore", "Hong Kong", "Taiwan", "China",
  "India", "United Arab Emirates", "Saudi Arabia", "Israel", "Turkey",
  "Brazil", "Mexico", "Argentina", "Chile", "Colombia",
  "South Africa", "Nigeria", "Kenya", "Egypt",
  "New Zealand", "Philippines", "Thailand", "Malaysia", "Indonesia", "Vietnam"
].sort();

// ============================================================================
// GOOGLE MAPS LOADER - Loads script once globally
// ============================================================================
let isGoogleMapsLoaded = false;
let googleMapsLoadPromise = null;

async function loadGoogleMaps() {
  if (isGoogleMapsLoaded) {
    return Promise.resolve();
  }

  if (googleMapsLoadPromise) {
    return googleMapsLoadPromise;
  }

  googleMapsLoadPromise = new Promise(async (resolve, reject) => {
    try {
      // Check if already loaded
      if (window.google?.maps?.places) {
        isGoogleMapsLoaded = true;
        resolve();
        return;
      }

      // Fetch API key from backend
      const keyResponse = await fetch('/functions/googleApiKey');
      if (!keyResponse.ok) {
        reject(new Error('Failed to load API key'));
        return;
      }

      const { apiKey } = await keyResponse.json();
      if (!apiKey) {
        reject(new Error('API key not configured'));
        return;
      }

      // Load script
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&callback=initGoogleMaps`;
      script.async = true;
      script.defer = true;

      window.initGoogleMaps = () => {
        isGoogleMapsLoaded = true;
        resolve();
      };

      script.onerror = () => reject(new Error('Failed to load Google Maps'));
      document.head.appendChild(script);

    } catch (error) {
      reject(error);
    }
  });

  return googleMapsLoadPromise;
}

// ============================================================================
// SMART BUSINESS SCANNER COMPONENT
// ============================================================================
export default function SmartBusinessScanner({ onScanComplete }) {
  // Form state
  const [email, setEmail] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [placeId, setPlaceId] = useState('');

  // UI state
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [mapsLoaded, setMapsLoaded] = useState(false);
  const [mapsError, setMapsError] = useState(null);
  const [autoFilledFields, setAutoFilledFields] = useState([]);

  // Refs
  const businessInputRef = useRef(null);
  const autocompleteRef = useRef(null);

  // ========================================
  // Load Google Maps on mount
  // ========================================
  useEffect(() => {
    loadGoogleMaps()
      .then(() => setMapsLoaded(true))
      .catch((error) => {
        console.warn('Google Maps failed to load:', error);
        setMapsError(error.message);
      });
  }, []);

  // ========================================
  // Initialize autocomplete when Maps loads
  // ========================================
  useEffect(() => {
    if (!mapsLoaded || !businessInputRef.current || autocompleteRef.current) return;

    try {
      const autocomplete = new window.google.maps.places.Autocomplete(
        businessInputRef.current,
        {
          types: ['establishment'],
          fields: ['place_id', 'name', 'formatted_address', 'address_components']
        }
      );

      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        
        if (!place.place_id) {
          console.warn('No place_id found');
          return;
        }

        console.log('✅ Place selected:', place);

        // Set business name
        setBusinessName(place.name || '');
        setPlaceId(place.place_id);

        // Extract address components
        const components = place.address_components || [];
        const filled = [];

        const getComponent = (type, useShort = false) => {
          const comp = components.find(c => c.types.includes(type));
          return comp ? (useShort ? comp.short_name : comp.long_name) : '';
        };

        const cityValue = getComponent('locality');
        const stateValue = getComponent('administrative_area_level_1', true);
        const countryValue = getComponent('country');
        const zipValue = getComponent('postal_code');

        if (cityValue) {
          setCity(stateValue ? `${cityValue}, ${stateValue}` : cityValue);
          filled.push('city');
        }

        if (countryValue) {
          const matchingCountry = COUNTRIES.find(c => 
            c.toLowerCase() === countryValue.toLowerCase() ||
            c.toLowerCase().includes(countryValue.toLowerCase())
          );
          if (matchingCountry) {
            setCountry(matchingCountry);
            filled.push('country');
          }
        }

        if (zipValue) {
          setPostalCode(zipValue);
          filled.push('postal');
        }

        setAutoFilledFields(filled);
      });

      autocompleteRef.current = autocomplete;

    } catch (error) {
      console.error('Autocomplete initialization failed:', error);
    }
  }, [mapsLoaded]);

  // ========================================
  // Email validation
  // ========================================
  const handleEmailChange = (e) => {
    const value = e.target.value;
    setEmail(value);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setIsEmailValid(regex.test(value));
  };

  // ========================================
  // Run scan
  // ========================================
  const handleScan = async () => {
    // Validation
    if (!isEmailValid) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!businessName || businessName.trim().length < 2) {
      toast.error('Please enter a business name');
      return;
    }

    if (!country) {
      toast.error('Please select a country');
      return;
    }

    setIsScanning(true);

    try {
      // Call backend scanner
      const response = await fetch('/functions/scanner/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          place_id: placeId || null,
          business_name: businessName,
          location: city || 'Unknown',
          country: country
        })
      });

      const data = await response.json();

      if (!data.success || !data.place) {
        toast.error(data.error || 'Scan failed. Please try again.');
        setIsScanning(false);
        return;
      }

      // Success!
      toast.success('✅ Business found! Analyzing visibility...');

      // Pass data to parent component
      if (onScanComplete) {
        onScanComplete({
          email: email,
          business: data.place,
          metadata: {
            city: city,
            country: country,
            postal: postalCode
          }
        });
      }

    } catch (error) {
      console.error('Scan error:', error);
      toast.error('Connection error. Please try again.');
    } finally {
      setIsScanning(false);
    }
  };

  // ========================================
  // Render
  // ========================================
  return (
    <Card className="max-w-3xl mx-auto shadow-2xl border-0 bg-white/90 backdrop-blur-xl rounded-3xl">
      <CardContent className="p-8 lg:p-10">
        
        {/* Maps Status Banner */}
        {mapsLoaded && !mapsError && (
          <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-bold text-green-900 text-sm">✨ Smart Search Active</p>
                <p className="text-green-700 text-xs">
                  Type your business name below — we'll auto-fill everything from Google Places!
                </p>
              </div>
            </div>
          </div>
        )}

        {mapsError && (
          <div className="mb-6 p-4 bg-amber-50 border-2 border-amber-200 rounded-xl">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <div>
                <p className="font-bold text-amber-900 text-sm">Manual Entry Mode</p>
                <p className="text-amber-700 text-xs">
                  Smart search unavailable. You can still enter details manually.
                </p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={(e) => { e.preventDefault(); handleScan(); }} className="space-y-6">
          
          {/* Email */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <Mail className="w-4 h-4 inline mr-1" />
              Your Email *
            </label>
            <div className="relative">
              <Input
                type="email"
                value={email}
                onChange={handleEmailChange}
                placeholder="email@example.com"
                className={cn(
                  "h-12 text-base transition-all border-2 rounded-xl",
                  isEmailValid ? "border-green-500 bg-green-50/30" : "border-slate-300"
                )}
                required
              />
              {isEmailValid && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <Check className="w-5 h-5 text-green-600" />
                </div>
              )}
            </div>
          </div>

          {/* Business Name */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <Building className="w-4 h-4 inline mr-1" />
              Business Name *
              {mapsLoaded && (
                <Badge className="ml-2 bg-purple-100 text-purple-700">
                  Smart Search
                </Badge>
              )}
            </label>
            <Input
              ref={businessInputRef}
              type="text"
              value={businessName}
              onChange={(e) => {
                setBusinessName(e.target.value);
                if (placeId) {
                  setPlaceId('');
                  setAutoFilledFields([]);
                }
              }}
              placeholder={mapsLoaded ? "Type to search: e.g., Starbucks Dubai" : "Enter business name"}
              className="h-12 text-base border-2 border-slate-300 rounded-xl"
              autoComplete="off"
              required
            />
            {placeId && (
              <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                <Check className="w-3 h-3" />
                ✅ Verified from Google Places
              </p>
            )}
          </div>

          {/* City & Country */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                <MapPin className="w-4 h-4 inline mr-1" />
                City / Region
                {autoFilledFields.includes('city') && (
                  <span className="ml-2 text-green-600 text-xs">✓</span>
                )}
              </label>
              <Input
                type="text"
                value={city}
                onChange={(e) => {
                  setCity(e.target.value);
                  setAutoFilledFields(prev => prev.filter(f => f !== 'city'));
                }}
                placeholder="e.g., Dubai"
                className={cn(
                  "h-12 text-base border-2 rounded-xl",
                  autoFilledFields.includes('city') ? "border-green-300 bg-green-50/30" : "border-slate-300"
                )}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                <Globe className="w-4 h-4 inline mr-1" />
                Country *
                {autoFilledFields.includes('country') && (
                  <span className="ml-2 text-green-600 text-xs">✓</span>
                )}
              </label>
              <Select
                value={country}
                onValueChange={(value) => {
                  setCountry(value);
                  setAutoFilledFields(prev => prev.filter(f => f !== 'country'));
                }}
              >
                <SelectTrigger className={cn(
                  "h-12 text-base border-2 rounded-xl",
                  autoFilledFields.includes('country') ? "border-green-300 bg-green-50/30" : "border-slate-300"
                )}>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {COUNTRIES.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Postal Code */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Postal Code <span className="text-slate-400">(optional)</span>
              {autoFilledFields.includes('postal') && (
                <span className="ml-2 text-green-600 text-xs">✓</span>
              )}
            </label>
            <Input
              type="text"
              value={postalCode}
              onChange={(e) => {
                setPostalCode(e.target.value);
                setAutoFilledFields(prev => prev.filter(f => f !== 'postal'));
              }}
              placeholder="e.g., 10117"
              className={cn(
                "h-12 text-base border-2 rounded-xl",
                autoFilledFields.includes('postal') ? "border-green-300 bg-green-50/30" : "border-slate-300"
              )}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isScanning || !isEmailValid || !businessName || !country}
            className={cn(
              "w-full h-14 text-base font-semibold rounded-xl transition-all",
              isScanning
                ? "bg-gradient-to-r from-purple-400 to-indigo-400 cursor-not-allowed"
                : !isEmailValid || !businessName || !country
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 opacity-50 cursor-not-allowed"
                  : "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 hover:shadow-xl hover:-translate-y-1"
            )}
          >
            {isScanning ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Scanning...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2" />
                Run Free Scan
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>

        </form>
      </CardContent>
    </Card>
  );
}