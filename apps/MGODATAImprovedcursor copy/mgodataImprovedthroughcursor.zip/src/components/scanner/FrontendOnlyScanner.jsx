// ============================================================================
// MGO DATA - SMART BUSINESS SCANNER (Dynamic Scoring)
// Calls backend scanner with real MEO/GEO algorithm
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Building, 
  MapPin, 
  Globe, 
  Mail, 
  Sparkles, 
  Check, 
  Loader2,
  Zap,
  ArrowRight
} from 'lucide-react';
import { toast }  from 'sonner';
import { cn } from '@/lib/utils';

// Global country list
const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Australia", "Germany", "France",
  "Spain", "Italy", "Netherlands", "Belgium", "Switzerland", "Austria",
  "Sweden", "Norway", "Denmark", "Finland", "Ireland", "Portugal", "Poland",
  "Japan", "South Korea", "Singapore", "Hong Kong", "Taiwan", "China",
  "India", "United Arab Emirates", "Saudi Arabia", "Israel", "Turkey",
  "Brazil", "Mexico", "Argentina", "Chile", "Colombia",
  "South Africa", "Nigeria", "Kenya", "Egypt",
  "New Zealand", "Philippines", "Thailand", "Malaysia", "Indonesia", "Vietnam"
].sort();

export default function FrontendOnlyScanner({ onScanComplete, scanMode = 'local', onBusinessNameChange, onUrlChange }) {
  // Form state
  const [email, setEmail] = useState('');
  const [url, setUrl] = useState('');
  const [isUrlValid, setIsUrlValid] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [placeId, setPlaceId] = useState('');

  // UI state
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState('');
  const [autoFilledFields, setAutoFilledFields] = useState([]);
  
  // Autocomplete state
  const [suggestions, setSuggestions] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // Refs
  const businessInputRef = useRef(null);
  const dropdownRef = useRef(null);
  const debounceTimer = useRef(null);

  // ========================================
  // Close dropdown when clicking outside
  // ========================================
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current && 
        !dropdownRef.current.contains(event.target) &&
        businessInputRef.current &&
        !businessInputRef.current.contains(event.target)
      ) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ========================================
  // Email validation
  // ========================================
  const handleEmailChange = (e) => {
    const value = e.target.value;
    setEmail(value);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setIsEmailValid(regex.test(value));
  };

  const handleUrlChange = (e) => {
    const value = e.target.value;
    setUrl(value);
    if (onUrlChange) onUrlChange(value);
    try {
      new URL(value);
      setIsUrlValid(true);
    } catch {
      setIsUrlValid(false);
    }
  };

  // ========================================
  // Fetch autocomplete suggestions
  // ========================================
  const fetchSuggestions = async (input) => {
    if (!input || input.length < 2) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }

    clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(async () => {
      setIsLoadingSuggestions(true);

      try {
        console.log('📡 Fetching autocomplete for:', input);

        const response = await fetch('/functions/autocomplete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ input })
        });

        const data = await response.json();
        console.log('📦 Autocomplete response:', data);

        if (data.success && data.predictions) {
          setSuggestions(data.predictions);
          setShowDropdown(data.predictions.length > 0);
        } else {
          setSuggestions([]);
          setShowDropdown(false);
        }

      } catch (error) {
        console.error('❌ Autocomplete error:', error);
        setSuggestions([]);
        setShowDropdown(false);
      } finally {
        setIsLoadingSuggestions(false);
      }
    }, 400);
  };

  // ========================================
  // Handle business name input
  // ========================================
  const handleBusinessNameChange = (e) => {
    const value = e.target.value;
    setBusinessName(value);
    if (onBusinessNameChange) onBusinessNameChange(value);
    
    if (placeId) {
      setPlaceId('');
      setAutoFilledFields([]);
    }

    fetchSuggestions(value);
  };

  // ========================================
  // Handle business selection
  // ========================================
  const handleSelectBusiness = async (prediction) => {
    console.log('✅ Business selected:', prediction);
    
    setBusinessName(prediction.displayName);
    if (onBusinessNameChange) onBusinessNameChange(prediction.displayName);
    setPlaceId(prediction.place_id);
    setShowDropdown(false);

    const secondaryText = prediction.secondaryText || '';
    if (secondaryText) {
      const parts = secondaryText.split(',').map(s => s.trim());
      
      if (parts.length >= 1) {
        setCity(parts[0]);
        setAutoFilledFields(prev => [...prev, 'city']);
      }
      
      if (parts.length >= 2) {
        const lastPart = parts[parts.length - 1];
        const matchingCountry = COUNTRIES.find(c => 
          c.toLowerCase() === lastPart.toLowerCase() ||
          c.toLowerCase().includes(lastPart.toLowerCase()) ||
          lastPart.toLowerCase().includes(c.toLowerCase())
        );
        
        if (matchingCountry) {
          setCountry(matchingCountry);
          setAutoFilledFields(prev => [...prev, 'country']);
        }
      }
    }

    toast.success(`✅ Selected: ${prediction.displayName}`);
  };

  // ========================================
  // Run Online Scan
  // ========================================
  const handleOnlineScan = async () => {
    console.log('=== ONLINE SCAN INITIATED ===');

    if (!isEmailValid) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!isUrlValid) {
      toast.error('Please enter a valid URL (include https://)');
      return;
    }

    setIsScanning(true);
    setScanProgress('Analyzing website signals...');

    try {
      const response = await fetch('/functions/runOnlineScan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, email })
      });

      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        // This catches the "Deployment..." or non-JSON error
        console.error("Raw response:", text);
        throw new Error(`Scanner error: ${text.substring(0, 100)}`);
      }
      
      if (!data.success) {
        throw new Error(data.error || 'Scan failed');
      }

      console.log('✅ Online scan result:', data.result);
      
      if (onScanComplete) {
        // Ensure email is passed from state
        onScanComplete({ ...data.result, email });
      }

    } catch (error) {
      console.error('❌ Scan error:', error);
      toast.error(error.message);
    } finally {
      setIsScanning(false);
      setScanProgress('');
    }
  };

  // ========================================
  // Run Dynamic Scan with REAL AI visibility
  // ========================================
  const handleScan = async () => {
    if (scanMode === 'online') {
      handleOnlineScan();
      return;
    }

    console.log('=== SCAN INITIATED (Real AI Visibility Checks) ===');

    // Validation
    if (!isEmailValid) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!businessName || businessName.trim().length < 2) {
      toast.error('Please enter a business name');
      return;
    }

    if (!country) {
      toast.error('Please select a country');
      return;
    }

    if (!placeId) {
      toast.error('Please select a business from the dropdown');
      return;
    }

    setIsScanning(true);
    setScanProgress('Fetching business details...');

    try {
      console.log('📡 Step 1: Fetching Google Places data...');

      // Parse city and state
      const cityParts = city.split(',').map(s => s.trim());
      const cityName = cityParts[0] || 'Unknown';
      const stateName = cityParts[1] || cityName;

      // Call scanner endpoint with city/state for AI queries
      const scannerResponse = await fetch('/functions/scanner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          place_id: placeId,
          city: cityName,
          state: stateName
        })
      });

      const scannerData = await scannerResponse.json();
      console.log('📦 Scanner response:', scannerData);

      if (!scannerResponse.ok || !scannerData.success) {
        throw new Error(scannerData.error || 'Failed to fetch business details');
      }

      const { result } = scannerData;

      // Show AI check progress
      if (result.geoDetails?.method === 'real-ai-check') {
        setScanProgress('Checking AI visibility (ChatGPT, Gemini)...');
        console.log('🤖 AI engines checked:', result.geoDetails.details.enginesChecked);
      } else {
        setScanProgress('Calculating visibility scores...');
      }

      console.log('✅ Dynamic scores calculated:');
      console.log('   MEO:', result.scores.meo);
      console.log('   GEO:', result.scores.geo, result.geoDetails?.method === 'real-ai-check' ? '(Real AI checks)' : '(Fallback)');
      console.log('   Overall:', result.scores.overall);
      console.log('   Percentile:', result.percentileText);

      setScanProgress('Preparing results...');

      // Build final scan result with dynamic scores
      const scanResult = {
        email: email,
        business: {
          ...result.place,
          address: result.place.formattedAddress
        },
        scores: {
          meo: result.scores.meo,
          geo: result.scores.geo,
          final: result.scores.overall
        },
        percentile: result.percentile,
        percentileText: result.percentileText,
        optimizationBar: result.optimizationBar,
        geoDetails: result.geoDetails, // Include AI visibility details
        metadata: {
          city: cityName,
          state: stateName,
          country: country,
          postal: postalCode,
          scanned_at: new Date().toISOString()
        }
      };

      console.log('✅ Complete scan result:', scanResult);

      // Store in session storage
      sessionStorage.setItem('scanResults', JSON.stringify(scanResult));

      // ✅ INCREMENT SCAN COUNTER
      try {
        console.log('📊 Incrementing scan counter...');
        const counterResponse = await fetch('/functions/scanCounter', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });
        
        if (counterResponse.ok) {
          const counterData = await counterResponse.json();
          console.log('✅ Scan counter updated:', counterData.count);
          
          // Dispatch event for ScanCounter component to update
          window.dispatchEvent(new CustomEvent('scan:completed'));
        } else {
          console.warn('⚠️ Failed to update scan counter (non-critical)');
        }
      } catch (counterError) {
        console.warn('⚠️ Scan counter update failed (non-critical):', counterError);
        // Don't fail the scan if counter fails - this is non-critical
      }

      toast.success('✅ Scan complete! Redirecting to results...');

      // Pass to parent
      if (onScanComplete) {
        setTimeout(() => {
          onScanComplete(scanResult);
        }, 500);
      }

    } catch (error) {
      console.error('❌ Scan error:', error);
      toast.error(error.message || 'Scan failed. Please try again.');
      setIsScanning(false);
      setScanProgress('');
    }
  };

  // ========================================
  // Render
  // ========================================
  return (
    <Card className="max-w-3xl mx-auto shadow-2xl border-0 bg-white/90 backdrop-blur-xl rounded-3xl overflow-visible">
      <CardContent className="p-8 lg:p-10 overflow-visible">
        
        {/* Info Banner */}
        <div className="mb-6 p-4 bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-xl">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <div>
              <p className="font-bold text-purple-900 text-sm">✨ Smart Search Enabled</p>
              <p className="text-purple-700 text-xs">
                Type your business name and select from the dropdown to auto-fill everything!
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); handleScan(); }} className="space-y-6 overflow-visible">
          
          {/* Email - Common for both modes */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <Mail className="w-4 h-4 inline mr-1" />
              Your Email *
            </label>
            <div className="relative">
              <Input
                type="email"
                value={email}
                onChange={handleEmailChange}
                placeholder="email@example.com"
                className={cn(
                  "h-12 text-base transition-all border-2 rounded-xl",
                  isEmailValid ? "border-green-500 bg-green-50/30" : "border-slate-300"
                )}
                required
              />
              {isEmailValid && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <Check className="w-5 h-5 text-green-600" />
                </div>
              )}
            </div>
          </div>

          {scanMode === 'local' ? (
            <>
              {/* Local Business Form Inputs */}
              <div className="relative">
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  <Building className="w-4 h-4 inline mr-1" />
                  Business Name *
                  <Badge className="ml-2 bg-purple-100 text-purple-700">
                    Smart Search
                  </Badge>
                </label>
                <div className="relative">
                  <Input
                    ref={businessInputRef}
                    type="text"
                    value={businessName}
                    onChange={handleBusinessNameChange}
                    onFocus={() => businessName.length >= 2 && fetchSuggestions(businessName)}
                    placeholder="Type to search: e.g., Starbucks Dubai Mall"
                    className="h-12 text-base border-2 border-slate-300 rounded-xl"
                    autoComplete="off"
                    required
                  />
                  {isLoadingSuggestions && (
                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                      <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                    </div>
                  )}
                </div>
                
                {showDropdown && suggestions.length > 0 && (
                  <div
                    ref={dropdownRef}
                    className="absolute z-[9999] w-full mt-2 bg-white border-2 border-purple-300 rounded-xl shadow-2xl max-h-64 overflow-y-auto"
                  >
                    {suggestions.map((prediction, index) => (
                      <button
                        key={prediction.place_id || index}
                        type="button"
                        onClick={() => handleSelectBusiness(prediction)}
                        className={cn(
                          "w-full px-4 py-3 text-left hover:bg-purple-50 active:bg-purple-100 transition-colors border-b border-slate-100",
                          index === 0 && "rounded-t-xl",
                          index === suggestions.length - 1 && "border-b-0 rounded-b-xl"
                        )}
                      >
                        <div className="font-semibold text-sm text-slate-900">
                          {prediction.displayName}
                        </div>
                        {prediction.secondaryText && (
                          <div className="text-xs text-slate-500 mt-0.5">
                            {prediction.secondaryText}
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                )}

                {placeId && (
                  <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    ✅ Business verified from Google Places
                  </p>
                )}
                {!placeId && businessName && businessName.length >= 2 && !isLoadingSuggestions && (
                  <p className="text-xs text-purple-600 mt-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    {suggestions.length > 0 ? 'Select a business from the dropdown' : 'Type more to see suggestions'}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    <MapPin className="w-4 h-4 inline mr-1" />
                    City / Region
                    {autoFilledFields.includes('city') && (
                      <span className="ml-2 text-green-600 text-xs">✓ Auto-filled</span>
                    )}
                  </label>
                  <Input
                    type="text"
                    value={city}
                    onChange={(e) => {
                      setCity(e.target.value);
                      setAutoFilledFields(prev => prev.filter(f => f !== 'city'));
                    }}
                    placeholder="e.g., Dubai"
                    className={cn(
                      "h-12 text-base border-2 rounded-xl",
                      autoFilledFields.includes('city') ? "border-green-300 bg-green-50/30" : "border-slate-300"
                    )}
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    <Globe className="w-4 h-4 inline mr-1" />
                    Country *
                    {autoFilledFields.includes('country') && (
                      <span className="ml-2 text-green-600 text-xs">✓ Auto-filled</span>
                    )}
                  </label>
                  <Select
                    value={country}
                    onValueChange={(value) => {
                      setCountry(value);
                      setAutoFilledFields(prev => prev.filter(f => f !== 'country'));
                    }}
                  >
                    <SelectTrigger className={cn(
                      "h-12 text-base border-2 rounded-xl",
                      autoFilledFields.includes('country') ? "border-green-300 bg-green-50/30" : "border-slate-300"
                    )}>
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {COUNTRIES.map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Postal Code <span className="text-slate-400">(optional)</span>
                  {autoFilledFields.includes('postal') && (
                    <span className="ml-2 text-green-600 text-xs">✓ Auto-filled</span>
                  )}
                </label>
                <Input
                  type="text"
                  value={postalCode}
                  onChange={(e) => {
                    setPostalCode(e.target.value);
                    setAutoFilledFields(prev => prev.filter(f => f !== 'postal'));
                  }}
                  placeholder="e.g., 10117"
                  className={cn(
                    "h-12 text-base border-2 rounded-xl",
                    autoFilledFields.includes('postal') ? "border-green-300 bg-green-50/30" : "border-slate-300"
                  )}
                />
              </div>
            </>
          ) : (
            /* Online Business Form Input */
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                <Globe className="w-4 h-4 inline mr-1" />
                Website URL *
              </label>
              <div className="relative">
                <Input
                  type="url"
                  value={url}
                  onChange={handleUrlChange}
                  placeholder="https://example.com"
                  className={cn(
                    "h-12 text-base transition-all border-2 rounded-xl",
                    isUrlValid ? "border-green-500 bg-green-50/30" : "border-slate-300"
                  )}
                  required
                />
                {isUrlValid && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <Check className="w-5 h-5 text-green-600" />
                  </div>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Powered by AI — we analyze your site, presence in AI answers, and visibility signals across the web.
              </p>
            </div>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isScanning || !isEmailValid || (scanMode === 'local' ? (!businessName || !country || !placeId) : !isUrlValid)}
            className={cn(
              "w-full h-14 text-base font-semibold rounded-xl transition-all",
              isScanning
                ? "bg-gradient-to-r from-purple-400 to-indigo-400 cursor-not-allowed"
                : (!isEmailValid || (scanMode === 'local' ? (!businessName || !country || !placeId) : !isUrlValid))
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 opacity-50 cursor-not-allowed"
                  : "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 hover:shadow-xl hover:-translate-y-1"
            )}
          >
            {isScanning ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                {scanProgress || 'Scanning...'}
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2" />
                Run Free Scan
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>

          {scanMode === 'local' && !placeId && businessName && businessName.length >= 2 && (
            <p className="text-center text-sm text-purple-600">
              ⚠️ Please select your business from the dropdown above to enable scanning
            </p>
          )}

        </form>
      </CardContent>
    </Card>
  );
}