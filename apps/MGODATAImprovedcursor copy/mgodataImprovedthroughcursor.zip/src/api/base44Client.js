import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68d742e6c4913147eef6a1ba", 
  requiresAuth: true // Ensure authentication is required for all operations
});
