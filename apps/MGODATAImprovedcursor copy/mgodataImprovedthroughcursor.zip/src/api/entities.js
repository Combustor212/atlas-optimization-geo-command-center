import { base44 } from './base44Client';


export const Business = base44.entities.Business;

export const AuditReport = base44.entities.AuditReport;

export const AuditTask = base44.entities.AuditTask;

export const VisibilityCheck = base44.entities.VisibilityCheck;

export const Prospect = base44.entities.Prospect;

export const AuditResult = base44.entities.AuditResult;

export const ContentKit = base44.entities.ContentKit;

export const Report = base44.entities.Report;

export const BusinessAssistantResponse = base44.entities.BusinessAssistantResponse;

export const Subscription = base44.entities.Subscription;

export const ScanCounter = base44.entities.ScanCounter;

export const FAQ = base44.entities.FAQ;

export const Review = base44.entities.Review;

export const SEOSettings = base44.entities.SEOSettings;

export const BusinessConnection = base44.entities.BusinessConnection;

export const ScanLead = base44.entities.ScanLead;

export const WaitlistEntry = base44.entities.WaitlistEntry;

export const ScanResult = base44.entities.ScanResult;



// auth sdk:
export const User = base44.auth;