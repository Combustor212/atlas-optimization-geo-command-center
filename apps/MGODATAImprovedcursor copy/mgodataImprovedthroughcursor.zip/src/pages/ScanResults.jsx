import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import {
  RotateCcw,
  Lightbulb,
  Star,
  Globe,
  MapPin,
  Loader2,
  Target,
  Settings,
  CheckCircle2,
  ChevronDown,
  ArrowRight,
  Sparkles,
  Zap,
  Calendar,
  Image,
  MessageCircle,
  ThumbsUp,
  ThumbsDown,
  Users,
  Building,
  Check,
  Search,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import MGOLogo from '../components/MGOLogo';
import CircularProgress from '../components/CircularProgress';
import ShareButton from '../components/ShareButton';

const AnimatedCounter = ({ value, duration = 2000 }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime;
    let animationFrame;

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      setCount(Math.floor(value * percentage));
      if (percentage < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [value, duration]);

  return <span>{count}</span>;
};

const ScoreGaugeCard = ({ score, label, sublabel, color, description, showBeta, delay = 0 }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay, ease: [0.34, 1.56, 0.64, 1] }}
      className="flex flex-col items-center"
    >
      <div
        className="relative cursor-help group"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-200 via-indigo-200 to-blue-200 blur-2xl opacity-30 group-hover:opacity-60 transition-opacity duration-500" />
        
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-300 via-indigo-300 to-blue-300 blur-md opacity-50 group-hover:opacity-70 transition-opacity" />
          <div className="relative bg-white rounded-full p-2 shadow-xl">
            <CircularProgress value={score} color={color} size={120} thickness={10} />
          </div>
        </div>

        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 w-64 p-3 bg-slate-900 text-white text-xs rounded-xl shadow-2xl z-50"
          >
            {description}
            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-900"></div>
          </motion.div>
        )}
      </div>

      <p className="font-bold text-slate-900 mt-5 text-lg">{label}</p>
      <p className="text-slate-500 text-sm font-medium">{sublabel}</p>
      
      {showBeta && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.3 }}
          className="mt-3"
        >
          <Badge className="bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-700 border border-purple-200 px-3 py-1 text-[10px] font-bold rounded-full shadow-sm hover:shadow-md hover:scale-105 transition-all">
            BETA
          </Badge>
        </motion.div>
      )}
    </motion.div>
  );
};

const EnrichedStatCard = ({ icon: Icon, title, value, subtitle, delay = 0, gradient }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className={cn(
        "border-2 rounded-xl shadow-md hover:shadow-lg transition-all",
        gradient
      )}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-white/80 backdrop-blur flex items-center justify-center shrink-0">
              <Icon className="w-6 h-6 text-purple-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-1">
                {title}
              </p>
              <p className="text-2xl font-black text-slate-900 mb-1">
                {value}
              </p>
              {subtitle && (
                <p className="text-xs text-slate-600">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const InsightCard = ({ icon: Icon, title, content, delay = 0 }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card 
        className="border border-slate-200 bg-white hover:shadow-lg hover:border-purple-200 transition-all duration-300 cursor-pointer group rounded-xl"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-50 to-indigo-50 flex items-center justify-center shrink-0 group-hover:from-purple-100 group-hover:to-indigo-100 transition-colors">
              <Icon className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-slate-900 text-sm mb-1">{title}</h3>
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-2"
                  >
                    <p className="text-xs text-slate-600 leading-relaxed">{content}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="shrink-0"
            >
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </motion.div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const IntegrationSimulationModal = ({ isOpen, onClose, onComplete }) => {
  const [stage, setStage] = useState('simulating');
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');

  const steps = [
    { label: 'Analyzing business data', progress: 25 },
    { label: 'Generating schema markup', progress: 50 },
    { label: 'Optimizing FAQs', progress: 75 },
    { label: 'Enhancing reviews', progress: 100 }
  ];

  useEffect(() => {
    if (!isOpen) {
      setStage('simulating');
      setProgress(0);
      setCurrentStep('');
      return;
    }

    let stepIndex = 0;
    const duration = 4000;
    const stepDuration = duration / steps.length;

    const intervalId = setInterval(() => {
      if (stepIndex < steps.length) {
        setCurrentStep(steps[stepIndex].label);
        setProgress(steps[stepIndex].progress);
        stepIndex++;
      } else {
        clearInterval(intervalId);
        setTimeout(() => setStage('complete'), 300);
      }
    }, stepDuration);

    return () => clearInterval(intervalId);
  }, [isOpen]);

  const integrationCards = [
    { title: "Added Schema Data", description: "LocalBusiness structured data added", icon: "🔗" },
    { title: "Optimized FAQs", description: "5 AI-optimized FAQ entries created", icon: "❓" },
    { title: "AI-Enhanced Reviews", description: "Testimonials optimized for AI discovery", icon: "⭐" }
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-8 max-h-[90vh] overflow-y-auto"
        >
          {stage === 'simulating' && (
            <div className="text-center space-y-6">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center"
              >
                <Settings className="w-8 h-8 text-white" />
              </motion.div>

              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">
                  Running Integration...
                </h2>
                <p className="text-slate-600 text-sm">
                  Optimizing your visibility for AI search engines
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium text-slate-700">
                  <span>{currentStep || 'Processing'}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full"
                    style={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>
            </div>
          )}

          {stage === 'complete' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.2 }}
                  className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center"
                >
                  <Check className="w-8 h-8 text-green-600" />
                </motion.div>

                <h2 className="text-2xl font-bold text-slate-900 mb-2">
                  Integration Complete
                </h2>
                <p className="text-slate-600 text-sm">
                  Your profile is now AI-optimized
                </p>
              </div>

              <div className="space-y-3">
                {integrationCards.map((card, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200"
                  >
                    <div className="text-2xl">{card.icon}</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 text-sm mb-0.5">{card.title}</h3>
                      <p className="text-xs text-slate-600">{card.description}</p>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0" />
                  </motion.div>
                ))}
              </div>

              <div className="space-y-2">
                <Button
                  onClick={onComplete}
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 h-11 text-sm font-semibold rounded-xl shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all"
                >
                  View Updated Results
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="w-full h-11 text-sm rounded-xl hover:bg-slate-50"
                >
                  Close
                </Button>
              </div>
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default function ScanResults() {
  const [scanData, setScanData] = useState(null);
  const [planRecommendation, setPlanRecommendation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showIntegrationModal, setShowIntegrationModal] = useState(false);
  const [scanId, setScanId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadAndSaveScan = async () => {
      const stored = sessionStorage.getItem('scanResults');
      const storedPlan = sessionStorage.getItem('planRecommendation');
      
      if (!stored) {
        setIsLoading(false);
        return;
      }

      try {
        const data = JSON.parse(stored);
        
        if (!data.scores || typeof data.scores.meo !== 'number' || typeof data.scores.geo !== 'number' || typeof data.scores.final !== 'number') {
          console.error('❌ Invalid or missing scores in scan data:', data);
          setIsLoading(false);
          return;
        }
        
        setScanData(data);
        
        if (storedPlan) {
          const planData = JSON.parse(storedPlan);
          setPlanRecommendation(planData);
        }
        
        if (data.business?.name) {
          document.title = `${data.business.name} — Visibility Report | MGO Data`;
        }

        // Save scan to database if not already saved
        if (!data.scanId) {
          try {
            const newScanId = `scan_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            
            await base44.entities.ScanResult.create({
              scanId: newScanId,
              email: data.email,
              business: data.business,
              scores: data.scores,
              enrichedData: data.enrichedData,
              insightSummary: data.insightSummary,
              percentile: data.percentile,
              metadata: data.metadata,
              createdAt: new Date().toISOString(), // Add creation timestamp
            });

            setScanId(newScanId);
            
            // Update sessionStorage with scanId
            data.scanId = newScanId;
            sessionStorage.setItem('scanResults', JSON.stringify(data));
          } catch (saveError) {
            console.error('Failed to save scan to database:', saveError);
            // Continue without saving - user can still see results
          }
        } else {
          setScanId(data.scanId);
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error("Failed to parse scan results:", error);
        setIsLoading(false);
      }
    };

    loadAndSaveScan();
  }, []);

  const handleNewScan = () => {
    sessionStorage.removeItem('scanResults');
    sessionStorage.removeItem('planRecommendation');
    navigate(createPageUrl('Landing'));
  };

  const handleUpgrade = () => {
    navigate(createPageUrl('pricing'));
  };

  const handleIntegrationDemo = () => {
    setShowIntegrationModal(true);
  };

  const handleIntegrationComplete = () => {
    setShowIntegrationModal(false);
    navigate(createPageUrl('IntegrationResults'));
  };

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="min-h-screen bg-slate-50 flex items-center justify-center"
      >
        <div className="text-center">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600 mx-auto mb-3" />
          <p className="text-slate-600 text-sm font-medium">Loading results...</p>
        </div>
      </motion.div>
    );
  }

  if (!scanData) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="min-h-screen bg-slate-50 flex items-center justify-center p-4"
      >
        <Card className="p-8 text-center max-w-md shadow-lg rounded-2xl">
          <CardContent>
            <MapPin className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">No Results Found</h2>
            <p className="text-slate-600 text-sm mb-6">
              We couldn't find your scan results. Please run a new scan.
            </p>
            <Button
              onClick={handleNewScan}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 rounded-xl shadow-lg hover:scale-105 transition-all"
            >
              Run New Scan
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // Check mode
  if (scanData.type === 'online') {
    const { url, scores, percentileInNiche, recommendedActions, niche } = scanData;
    
    const finalScore = Math.round(scores.overall || 0);
    const optimizationPercentage = finalScore;
    
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100"
      >
        {/* Header */}
        <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-slate-200 shadow-sm">
          <div className="max-w-[1040px] mx-auto px-6 py-3.5 flex items-center justify-between">
            <MGOLogo size="md" linkTo="/" />
            <div className="flex items-center gap-2">
              {scanId && <ShareButton scanId={scanId} />}
              <Button onClick={handleNewScan} variant="outline" size="sm">
                <RotateCcw className="w-4 h-4 mr-1.5" /> New Scan
              </Button>
            </div>
          </div>
        </div>

        <div className="max-w-[1040px] mx-auto px-6 py-16">
          <div className="space-y-16">
            {/* Hero Info */}
            <motion.div className="text-center space-y-5">
               <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 truncate max-w-3xl mx-auto">
                  {url}
               </h1>
               <p className="text-slate-500 flex items-center justify-center gap-2">
                  <Globe className="w-4 h-4" /> Online Business Scan
                  {niche && <span className="bg-slate-100 px-2 py-0.5 rounded text-xs border border-slate-200">{niche}</span>}
               </p>
               <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-full shadow-sm">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-sm text-purple-900 font-medium">
                    Top <span className="font-bold">{percentileInNiche || 50}%</span> in your niche
                  </span>
               </div>
            </motion.div>

            {/* Scores Grid */}
            <Card className="bg-white border border-slate-200 rounded-2xl shadow-lg">
               <CardContent className="p-10">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-6 mb-8 text-center">
                     <div>
                        <div className="text-sm font-semibold text-slate-500 mb-1">SEO</div>
                        <div className="text-2xl font-bold text-slate-900">{scores.seo || 0}</div>
                     </div>
                     <div>
                        <div className="text-sm font-semibold text-slate-500 mb-1">AI Presence</div>
                        <div className="text-2xl font-bold text-purple-600">{scores.aiPresence || 0}</div>
                     </div>
                     <div>
                        <div className="text-sm font-semibold text-slate-500 mb-1">Social</div>
                        <div className="text-2xl font-bold text-pink-600">{scores.social || 0}</div>
                     </div>
                     <div>
                        <div className="text-sm font-semibold text-slate-500 mb-1">Conversion</div>
                        <div className="text-2xl font-bold text-green-600">{scores.conversion || 0}</div>
                     </div>
                     <div>
                        <div className="text-sm font-semibold text-slate-500 mb-1">Technical</div>
                        <div className="text-2xl font-bold text-blue-600">{scores.technical || 0}</div>
                     </div>
                  </div>

                  {/* Overall Gauge */}
                  <div className="flex flex-col items-center justify-center pt-6 border-t border-slate-100">
                     <h3 className="text-lg font-bold text-slate-900 mb-4">Overall Online Visibility</h3>
                     <div className="w-full max-w-md">
                        <div className="flex justify-between text-sm mb-1">
                           <span>Score</span>
                           <span className="font-bold">{finalScore}/100</span>
                        </div>
                        <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                           <div 
                              className="h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
                              style={{ width: `${finalScore}%` }}
                           />
                        </div>
                     </div>
                  </div>
               </CardContent>
            </Card>

            {/* Growth Plan */}
            <div className="space-y-6">
               <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <Target className="w-6 h-6 text-purple-600" />
                  AI Visibility Growth Plan
               </h2>
               <div className="grid gap-4">
                  {recommendedActions && recommendedActions.map((action, idx) => (
                     <Card key={idx} className="border-l-4 border-l-purple-500 shadow-sm hover:shadow-md transition-all">
                        <CardContent className="p-5 flex items-start gap-4">
                           <div className="mt-1">
                              {action.category === 'SEO' && <Search className="w-5 h-5 text-blue-500" />}
                              {action.category === 'AI Presence' && <Brain className="w-5 h-5 text-purple-500" />}
                              {action.category === 'Social' && <MessageCircle className="w-5 h-5 text-pink-500" />}
                              {action.category === 'Conversion' && <Zap className="w-5 h-5 text-yellow-500" />}
                              {action.category === 'Technical' && <Settings className="w-5 h-5 text-slate-500" />}
                           </div>
                           <div>
                              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                                 {action.category}
                              </div>
                              <p className="text-slate-900 font-medium">
                                 {action.action}
                              </p>
                           </div>
                        </CardContent>
                     </Card>
                  ))}
               </div>
            </div>

            {/* CTA */}
            <div className="bg-slate-900 rounded-2xl p-8 text-center text-white">
               <h2 className="text-2xl font-bold mb-4">Ready to dominate your niche?</h2>
               <p className="text-slate-300 mb-8 max-w-xl mx-auto">
                  Join the beta to unlock full AI optimization tools for your online brand.
               </p>
               <Button onClick={handleUpgrade} className="bg-white text-slate-900 hover:bg-slate-100 font-bold px-8 py-4 h-auto text-lg rounded-xl">
                  Get Early Access
               </Button>
            </div>

          </div>
        </div>
      </motion.div>
    );
  }

  const { business, scores, enrichedData, insightSummary } = scanData;
  
  const meoScore = Math.round(scores.meo || 0);
  const geoScore = Math.round(scores.geo || 0);
  const finalScore = Math.round(scores.final || 0);
  
  const percentile = scanData.percentile || (() => {
    if (finalScore >= 90) return 95;
    if (finalScore >= 80) return 85;
    if (finalScore >= 70) return 60;
    if (finalScore >= 60) return 40;
    return 25;
  })();
  
  const optimizationPercentage = finalScore;

  const insights = [
    {
      icon: Lightbulb,
      title: "What This Means",
      content: finalScore >= 75 
        ? "Your business has strong visibility. Keep maintaining this presence to stay competitive." 
        : finalScore >= 60 
          ? "Your business has moderate visibility with significant room for improvement. Focus on the recommended actions below."
          : "Your visibility is limited. Most customers won't find you through AI or local search without optimization."
    },
    {
      icon: Globe,
      title: "Boost AI Visibility",
      content: "Add structured data (Schema.org) and FAQ pages to help AI engines like ChatGPT and Perplexity recommend your business in search results."
    },
    {
      icon: MapPin,
      title: "Optimize Google Business Profile",
      content: "Complete all GBP sections, add high-quality photos, respond to reviews, and post weekly updates to improve local rankings and visibility."
    },
    {
      icon: Star,
      title: "Build Review Authority",
      content: "Request more reviews from satisfied customers and respond professionally to all feedback. This strengthens trust signals across all platforms."
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100"
    >
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-slate-200 shadow-sm">
        <div className="max-w-[1040px] mx-auto px-6 py-3.5 flex items-center justify-between">
          <MGOLogo size="md" linkTo="/" />

          <div className="flex items-center gap-2">
            {scanId && <ShareButton scanId={scanId} />}
            <Button
              onClick={handleNewScan}
              variant="outline"
              size="sm"
              className="text-slate-700 border-slate-300 hover:bg-slate-100 rounded-lg h-9 text-sm transition-all"
            >
              <RotateCcw className="w-4 h-4 mr-1.5" />
              <span className="hidden sm:inline">New Scan</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-[1040px] mx-auto px-6 py-16">
        <div className="space-y-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-5"
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 leading-tight">
              {business.name}
            </h1>
            
            <p className="text-slate-500 text-base flex items-center justify-center gap-2">
              <MapPin className="w-4 h-4" />
              {business.address || business.formattedAddress}
            </p>

            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-full shadow-sm">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-purple-900 font-medium">
                Ranks higher than <span className="font-bold"><AnimatedCounter value={percentile} />%</span> of competitors
              </span>
            </div>
          </motion.div>

          <div className="h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent" />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-12"
          >
            <Card className="bg-white border border-slate-200 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-10 sm:p-12">
                
                <div className="grid grid-cols-3 gap-8 sm:gap-12 mb-8">
                  <ScoreGaugeCard
                    score={meoScore}
                    label="MEO"
                    sublabel="Maps"
                    color="url(#meoGradient)"
                    description="Google Business Profile optimization score"
                    showBeta={false}
                    delay={0}
                  />
                  <ScoreGaugeCard
                    score={geoScore}
                    label="GEO"
                    sublabel="AI Visibility"
                    color="url(#geoGradient)"
                    description="AI search engine presence score"
                    showBeta={true}
                    delay={0.1}
                  />
                  <ScoreGaugeCard
                    score={finalScore}
                    label="Overall"
                    sublabel="Combined"
                    color="url(#finalGradient)"
                    description="Combined visibility score"
                    showBeta={false}
                    delay={0.2}
                  />
                </div>

                <div className="space-y-2 pt-6 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-700">
                      {optimizationPercentage}% Optimized
                    </span>
                    <span className="text-xs text-slate-500">
                      {100 - optimizationPercentage}% potential improvement
                    </span>
                  </div>
                  <div className="h-3 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                    <motion.div
                      className="h-full bg-gradient-to-r from-purple-500 via-purple-600 to-indigo-600 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${optimizationPercentage}%` }}
                      transition={{ duration: 1.5, delay: 0.5, ease: "easeOut" }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {enrichedData && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-900 text-center">
                  Business Insights
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <EnrichedStatCard
                    icon={MessageCircle}
                    title="Reviews & Ratings"
                    value={`${enrichedData.reviews.total_count || 0} reviews`}
                    subtitle={`${enrichedData.reviews.average_rating || 0}★ average${enrichedData.reviews.last_review_date ? ` • Last: ${new Date(enrichedData.reviews.last_review_date).toLocaleDateString()}` : ''}`}
                    delay={0.3}
                    gradient="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200"
                  />

                  <EnrichedStatCard
                    icon={Image}
                    title="Photos & Media"
                    value={`${enrichedData.media?.photos_total || 0} photos`}
                    subtitle={`${enrichedData.listing_details?.open_now ? '✅ Open now' : '❌ Closed'} • ${enrichedData.listing_details?.primary_category || 'business'}`}
                    delay={0.4}
                    gradient="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200"
                  />
                </div>

                {enrichedData.media && (enrichedData.media.total_user_photos > 0 || enrichedData.media.total_owner_photos > 0) && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <EnrichedStatCard
                      icon={Users}
                      title="User Photos"
                      value={`${enrichedData.media.total_user_photos}`}
                      subtitle="Photos uploaded by customers"
                      delay={0.45}
                      gradient="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200"
                    />

                    <EnrichedStatCard
                      icon={Building}
                      title="Owner Photos"
                      value={`${enrichedData.media.total_owner_photos}`}
                      subtitle="Photos uploaded by business owner"
                      delay={0.5}
                      gradient="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200"
                    />
                  </div>
                )}

                {enrichedData.media?.popular_review_photo_url && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.55 }}
                  >
                    <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl overflow-hidden">
                      <CardContent className="p-6">
                        <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                          <Image className="w-4 h-4 text-indigo-600" />
                          Featured Photo
                        </h3>
                        <img 
                          src={enrichedData.media.popular_review_photo_url} 
                          alt="Popular business photo"
                          className="w-full h-48 object-cover rounded-lg shadow-md"
                          onError={(e) => { e.target.style.display = 'none'; }}
                        />
                      </CardContent>
                    </Card>
                  </motion.div>
                )}

                {(enrichedData.reviews?.top_positive_keywords?.length > 0 || enrichedData.reviews?.top_negative_keywords?.length > 0) && (
                  <Card className="border border-slate-200 bg-white rounded-xl">
                    <CardContent className="p-6">
                      <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <Star className="w-4 h-4 text-purple-600" />
                        Review Keywords
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {enrichedData.reviews.top_positive_keywords?.length > 0 && (
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <ThumbsUp className="w-4 h-4 text-green-600" />
                              <span className="text-xs font-semibold text-green-700 uppercase">
                                Positive Mentions
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {enrichedData.reviews.top_positive_keywords.map((keyword, idx) => (
                                <Badge key={idx} className="bg-green-100 text-green-700 border-green-200">
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {enrichedData.reviews.top_negative_keywords?.length > 0 && (
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <ThumbsDown className="w-4 h-4 text-red-600" />
                              <span className="text-xs font-semibold text-red-700 uppercase">
                                Needs Attention
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {enrichedData.reviews.top_negative_keywords.map((keyword, idx) => (
                                <Badge key={idx} className="bg-red-100 text-red-700 border-red-200">
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {insightSummary && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                  >
                    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-lg bg-purple-600 flex items-center justify-center shrink-0">
                            <Sparkles className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-sm font-bold text-purple-900 mb-2">
                              AI Analysis
                            </h3>
                            <p className="text-sm text-slate-700 leading-relaxed">
                              {insightSummary}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </div>
            )}
          </motion.div>

          <svg width="0" height="0" style={{ position: 'absolute' }}>
            <defs>
              <linearGradient id="meoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FBBF24" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
              <linearGradient id="geoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#C084FC" />
                <stop offset="100%" stopColor="#9333EA" />
              </linearGradient>
              <linearGradient id="finalGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#60A5FA" />
                <stop offset="100%" stopColor="#3B82F6" />
              </linearGradient>
            </defs>
          </svg>

          <div className="h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent" />

          {planRecommendation && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50/30 rounded-2xl shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center shrink-0">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-slate-900 mb-2">
                        Recommended Plan: {planRecommendation.plan}
                      </h3>
                      <p className="text-base text-slate-600 leading-relaxed">
                        {planRecommendation.reason}
                      </p>
                    </div>
                  </div>
                  
                  <div className="bg-white/60 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-700">
                        Businesses Scanned
                      </span>
                      <span className="text-2xl font-bold text-indigo-600">
                        {planRecommendation.owned_business_count}
                      </span>
                    </div>
                  </div>

                  <Button 
                    onClick={() => navigate(createPageUrl('pricing'))}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all"
                  >
                    View {planRecommendation.plan} Plan Details →
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                Insights & Recommended Actions
              </h2>

              <div className="space-y-3">
                {insights.map((insight, index) => (
                  <InsightCard
                    key={index}
                    icon={insight.icon}
                    title={insight.title}
                    content={insight.content}
                    delay={0.5 + (index * 0.1)}
                  />
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="hidden lg:block"
            >
              <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-green-50/30 rounded-2xl shadow-md sticky top-24">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <h3 className="text-sm font-bold text-slate-900">
                      On Waitlist
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                    You'll be first to access full AI optimization tools at launch.
                  </p>
                  <ul className="space-y-2 mb-4">
                    {['Early feature access', 'Priority onboarding', 'Beta pricing'].map((perk, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        {perk}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    size="sm" 
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-9 text-xs font-semibold rounded-lg shadow-md hover:shadow-lg hover:scale-[1.02] transition-all"
                  >
                    Stay Updated
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="lg:hidden"
            >
              <Card className="border-2 border-emerald-200 bg-gradient-to-r from-emerald-50 to-green-50/30 rounded-xl shadow-md">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <p className="text-xs font-bold text-slate-900">
                      Added to waitlist
                    </p>
                  </div>
                  <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white h-8 text-[11px] rounded-lg px-3 shadow-md hover:scale-105 transition-all">
                    Updates
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent" />

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1 }}
            className="relative overflow-hidden rounded-2xl shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600" />
            
            <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />

            <div className="relative p-12 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 1.2, type: "spring", stiffness: 200 }}
                className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30 shadow-2xl"
              >
                <Zap className="w-8 h-8 text-white" />
              </motion.div>

              <h2 className="text-3xl font-bold text-white mb-3 flex items-center justify-center gap-3">
                <Zap className="w-7 h-7" />
                Run Demo Optimization
              </h2>
              <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
                Simulate how AI boosts visibility, rankings, and customer reach
              </p>

              <Button
                onClick={handleIntegrationDemo}
                className="bg-white text-purple-600 hover:bg-slate-50 font-bold px-10 py-6 text-lg rounded-xl shadow-2xl hover:shadow-white/20 hover:scale-105 transition-all duration-300"
              >
                Run Demo
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>

              <p className="text-white/70 text-sm mt-6">
                Free simulation • See instant results • No credit card required
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      <IntegrationSimulationModal
        isOpen={showIntegrationModal}
        onClose={() => setShowIntegrationModal(false)}
        onComplete={handleIntegrationComplete}
      />

      <motion.div
        className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white border-t border-slate-700"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <div className="max-w-[1040px] mx-auto px-6 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
            <div>
              <p className="text-base font-bold mb-0.5">
                Ready to boost your scores?
              </p>
              <p className="text-sm text-slate-300">
                AI optimization, competitor insights, and automated reporting
              </p>
            </div>
            <Button
              onClick={handleUpgrade}
              className="bg-white text-slate-900 hover:bg-slate-100 font-bold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all"
            >
              Start for $0.99 →
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}