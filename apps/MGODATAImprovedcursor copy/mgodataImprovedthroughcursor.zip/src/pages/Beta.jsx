import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Mail, Loader2, ArrowLeft, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import MarketingHeader from '../components/MarketingHeader';
import SEOHead from '../components/cms/SEOHead';

export default function BetaWaitlistPage() {
  const [email, setEmail] = useState('');
  const [remaining, setRemaining] = useState(294);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasJoined, setHasJoined] = useState(false);
  const [error, setError] = useState('');

  // Fetch remaining spots on load
  useEffect(() => {
    const fetchRemaining = async () => {
      try {
        const res = await fetch('/functions/betaRemaining', { cache: 'no-store' });
        const json = await res.json();
        if (Number.isFinite(json.remaining)) {
          setRemaining(json.remaining);
        }
      } catch (err) {
        console.warn('Failed to fetch remaining:', err);
        // Keep fallback of 294
      }
    };
    fetchRemaining();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch('/functions/betaJoin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.toLowerCase().trim() })
      });

      const data = await res.json();

      if (data.ok) {
        setHasJoined(true);
        toast.success('Welcome to the waitlist!');
        
        // Update remaining count
        if (data.remaining !== undefined) {
          setRemaining(data.remaining);
        }
      } else if (data.reason === 'sold_out') {
        setError('The beta is full. Join our newsletter to be notified at launch.');
      } else if (data.reason === 'rate_limited') {
        setError('Too many attempts. Please try again in a few minutes.');
      } else {
        setError(data.error || 'Something went wrong. Please try again.');
      }
    } catch (err) {
      console.error('Join error:', err);
      setError('Connection error. Please check your internet and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (hasJoined) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/20">
        <SEOHead pageName="beta" />
        <MarketingHeader />
        
        <div className="pt-32 pb-20 px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto text-center"
          >
            {/* Success Icon */}
            <div className="w-20 h-20 mx-auto mb-8 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-xl">
              <Check className="w-10 h-10 text-white" />
            </div>

            {/* Success Message */}
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Thanks for joining the waitlist of the best companies.
            </h1>
            
            <p className="text-xl text-slate-600 mb-12 leading-relaxed">
              We'll email you when your beta access is unlocked. Share with a colleague to help them grab a spot.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                onClick={() => {
                  navigator.clipboard.writeText('https://mgodata.com/beta');
                  toast.success('Link copied to clipboard!');
                }}
                className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-8 py-6 text-base font-semibold rounded-xl shadow-lg"
              >
                📋 Copy Invite Link
              </Button>
              
              <Button
                variant="outline"
                asChild
                className="border-slate-300 hover:bg-slate-50 px-8 py-6 text-base font-semibold rounded-xl"
              >
                <a href="https://www.linkedin.com/company/mgodata" target="_blank" rel="noopener noreferrer">
                  🔗 Follow Our Progress
                </a>
              </Button>
            </div>

            {/* Remaining Counter */}
            {remaining > 0 && (
              <div className="inline-flex items-center gap-2 px-6 py-3 bg-amber-50 border-2 border-amber-200 rounded-full">
                <Sparkles className="w-5 h-5 text-amber-600" />
                <span className="text-amber-900 font-semibold">
                  {remaining} spots still available
                </span>
              </div>
            )}

            {/* Back to Home */}
            <div className="mt-16">
              <Link
                to="/"
                className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/20">
      <SEOHead pageName="beta" />
      <MarketingHeader />
      
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            {/* Beta Badge */}
            <Badge className="mb-6 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-5 py-2 text-sm font-bold shadow-lg">
              🚀 PRIVATE BETA
            </Badge>

            {/* Headline */}
            <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 leading-tight">
              Join the MGO Data<br />Private Beta
            </h1>

            {/* Subheadline */}
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              We're selecting 300 forward-thinking businesses for early access to AI-powered visibility.
            </p>

            {/* Counter Pill */}
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-white border-2 border-slate-200 rounded-full shadow-md">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-slate-600 font-medium">Live spots available</span>
              </div>
              <div className="h-6 w-px bg-slate-300" />
              <span className="text-2xl font-bold text-slate-900">
                {remaining} <span className="text-base font-medium text-slate-500">/ 300</span>
              </span>
            </div>
          </motion.div>

          {/* Email Capture Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="bg-white/80 backdrop-blur-sm border-2 border-slate-200 shadow-2xl rounded-[24px]">
              <CardContent className="p-8 md:p-12">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Email Input */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-3">
                      <Mail className="w-4 h-4 inline mr-2" />
                      Work Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="h-14 text-base border-2 border-slate-300 focus:border-amber-500 focus:ring-amber-500 rounded-xl"
                      disabled={isSubmitting}
                      required
                    />
                    <p className="text-xs text-slate-500 mt-2">
                      One spot per company email. Limited to 300 businesses.
                    </p>
                  </div>

                  {/* Error Message */}
                  {error && (
                    <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4">
                      <p className="text-sm text-red-700 font-medium">{error}</p>
                    </div>
                  )}

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={isSubmitting || !email || remaining <= 0}
                    className={cn(
                      "w-full h-14 text-base font-bold rounded-xl transition-all shadow-lg",
                      remaining <= 0
                        ? "bg-slate-400 cursor-not-allowed"
                        : "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white hover:shadow-xl hover:scale-[1.02]"
                    )}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Claiming Your Spot...
                      </>
                    ) : remaining <= 0 ? (
                      'Beta is Full'
                    ) : (
                      '✨ Claim My Spot'
                    )}
                  </Button>

                  {/* Trust Signals */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 text-xs text-slate-500">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-green-600" />
                      <span>No credit card required</span>
                    </div>
                    <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-300" />
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-green-600" />
                      <span>Early adopter pricing locked</span>
                    </div>
                    <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-300" />
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-green-600" />
                      <span>Priority support</span>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Social Proof */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-12 text-center"
          >
            <p className="text-sm text-slate-500 mb-4">Trusted by businesses in</p>
            <div className="flex flex-wrap justify-center gap-6 text-sm font-semibold text-slate-600">
              <span>🇺🇸 United States</span>
              <span>🇬🇧 United Kingdom</span>
              <span>🇦🇺 Australia</span>
              <span>🇨🇦 Canada</span>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}