import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Mail, Phone, MessageCircle, Check, Calendar, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import MarketingHeader from '../components/MarketingHeader';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const GetSupportPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    business: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Book a Call Modal State
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [callFormData, setCallFormData] = useState({
    name: '',
    email: '',
    phone: '',
    business: '',
    preferredTime: '',
    timezone: '',
    message: ''
  });
  const [isCallSubmitting, setIsCallSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await base44.integrations.Core.SendEmail({
        from_name: 'MGO Data Support',
        to: 'b@mgodata.com',
        subject: `Support Request from ${formData.name}`,
        body: `
          <h2>New Support Request</h2>
          <p><strong>Name:</strong> ${formData.name}</p>
          <p><strong>Email:</strong> ${formData.email}</p>
          <p><strong>Business:</strong> ${formData.business || 'Not provided'}</p>
          <p><strong>Message:</strong></p>
          <p>${formData.message}</p>
        `
      });

      setSubmitted(true);
      toast.success('Message sent successfully!');
      
      setTimeout(() => {
        setFormData({ name: '', email: '', business: '', message: '' });
        setSubmitted(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to send message:', error);
      toast.error('Failed to send message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCallSubmit = async (e) => {
    e.preventDefault();
    setIsCallSubmitting(true);

    try {
      await base44.integrations.Core.SendEmail({
        from_name: 'MGO Data - Book a Call',
        to: 'b@mgodata.com',
        subject: `📞 Call Request from ${callFormData.name}`,
        body: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: linear-gradient(135deg, #7E22CE 0%, #9333EA 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
              .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
              .field { margin-bottom: 15px; }
              .field-label { font-weight: bold; color: #7E22CE; }
              .field-value { margin-top: 5px; padding: 10px; background: white; border-radius: 6px; border: 1px solid #e5e7eb; }
              .cta { margin-top: 20px; padding: 15px; background: #E0F2FE; border-left: 4px solid #3B82F6; border-radius: 6px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h2 style="margin: 0;">📞 New Call Request</h2>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Someone wants to book a consultation call</p>
              </div>
              <div class="content">
                <div class="field">
                  <div class="field-label">Name:</div>
                  <div class="field-value">${callFormData.name}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">Email:</div>
                  <div class="field-value"><a href="mailto:${callFormData.email}">${callFormData.email}</a></div>
                </div>
                
                <div class="field">
                  <div class="field-label">Phone:</div>
                  <div class="field-value"><a href="tel:${callFormData.phone}">${callFormData.phone}</a></div>
                </div>
                
                <div class="field">
                  <div class="field-label">Business:</div>
                  <div class="field-value">${callFormData.business || 'Not provided'}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">Preferred Time:</div>
                  <div class="field-value">${callFormData.preferredTime}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">Timezone:</div>
                  <div class="field-value">${callFormData.timezone}</div>
                </div>
                
                ${callFormData.message ? `
                  <div class="field">
                    <div class="field-label">Message:</div>
                    <div class="field-value">${callFormData.message}</div>
                  </div>
                ` : ''}
                
                <div class="cta">
                  <strong>👉 Quick Actions:</strong><br/>
                  • Reply to schedule: <a href="mailto:${callFormData.email}">${callFormData.email}</a><br/>
                  • Call directly: <a href="tel:${callFormData.phone}">${callFormData.phone}</a>
                </div>
              </div>
            </div>
          </body>
          </html>
        `
      });

      toast.success('Call request sent! We\'ll contact you within 24 hours.');
      setIsCallModalOpen(false);
      
      // Reset form
      setCallFormData({
        name: '',
        email: '',
        phone: '',
        business: '',
        preferredTime: '',
        timezone: '',
        message: ''
      });
    } catch (error) {
      console.error('Failed to send call request:', error);
      toast.error('Failed to send request. Please try again.');
    } finally {
      setIsCallSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-white to-blue-50">
      <MarketingHeader />

      {/* Hero Section */}
      <div className="py-20 pt-32">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-900 mb-6">
              Get{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-blue-600">
                Support
              </span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Have questions? We're here to help you succeed
            </p>
          </div>

          {/* Contact Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="bg-white border-slate-200 shadow-lg">
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
              </CardHeader>
              <CardContent>
                {submitted ? (
                  <div className="text-center py-8">
                    <Check className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-slate-900 mb-2">Message Sent!</h3>
                    <p className="text-slate-600">We'll get back to you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="John Doe"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="john@example.com"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label htmlFor="business">Business Name</Label>
                      <Input
                        id="business"
                        value={formData.business}
                        onChange={(e) => setFormData({ ...formData, business: e.target.value })}
                        placeholder="Acme Corp"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label htmlFor="message">Message *</Label>
                      <Textarea
                        id="message"
                        required
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Tell us about your needs..."
                        rows={5}
                      />
                    </div>
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full h-12 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        'Send Message'
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200 shadow-lg">
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="w-6 h-6 text-cyan-600 mt-1" />
                    <div>
                      <p className="font-semibold text-slate-900">Email</p>
                      <a href="mailto:b@mgodata.com" className="text-cyan-600 hover:underline">
                        b@mgodata.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-6 h-6 text-cyan-600 mt-1" />
                    <div>
                      <p className="font-semibold text-slate-900">Phone</p>
                      <p className="text-slate-600">1-800-MGO-DATA</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MessageCircle className="w-6 h-6 text-cyan-600 mt-1" />
                    <div>
                      <p className="font-semibold text-slate-900">Live Chat</p>
                      <p className="text-slate-600">Available 9am-6pm EST</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-slate-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-green-600" />
                    Book a Free Consultation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4">
                    Not sure which plan is right for you? Book a 30-minute call with our team to discuss your goals.
                  </p>
                  <Button
                    onClick={() => setIsCallModalOpen(true)}
                    className="w-full h-12 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white"
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Book a Call
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white border-slate-200 shadow-lg">
                <CardHeader>
                  <CardTitle>Business Hours</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Monday - Friday</span>
                    <span className="font-semibold text-slate-900">9am - 6pm EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Saturday</span>
                    <span className="font-semibold text-slate-900">10am - 4pm EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Sunday</span>
                    <span className="font-semibold text-slate-900">Closed</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Book a Call Modal */}
      <Dialog open={isCallModalOpen} onOpenChange={setIsCallModalOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Calendar className="w-6 h-6 text-green-600" />
              Book a Free Consultation
            </DialogTitle>
            <DialogDescription>
              Fill out the form below and we'll contact you within 24 hours to schedule your call.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCallSubmit} className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="call-name">Name *</Label>
                <Input
                  id="call-name"
                  required
                  value={callFormData.name}
                  onChange={(e) => setCallFormData({ ...callFormData, name: e.target.value })}
                  placeholder="John Doe"
                  className="h-11"
                />
              </div>
              <div>
                <Label htmlFor="call-email">Email *</Label>
                <Input
                  id="call-email"
                  type="email"
                  required
                  value={callFormData.email}
                  onChange={(e) => setCallFormData({ ...callFormData, email: e.target.value })}
                  placeholder="john@example.com"
                  className="h-11"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="call-phone">Phone *</Label>
                <Input
                  id="call-phone"
                  type="tel"
                  required
                  value={callFormData.phone}
                  onChange={(e) => setCallFormData({ ...callFormData, phone: e.target.value })}
                  placeholder="+1 (555) 123-4567"
                  className="h-11"
                />
              </div>
              <div>
                <Label htmlFor="call-business">Business Name</Label>
                <Input
                  id="call-business"
                  value={callFormData.business}
                  onChange={(e) => setCallFormData({ ...callFormData, business: e.target.value })}
                  placeholder="Acme Corp"
                  className="h-11"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="call-time">Preferred Time *</Label>
                <Select
                  required
                  value={callFormData.preferredTime}
                  onValueChange={(value) => setCallFormData({ ...callFormData, preferredTime: value })}
                >
                  <SelectTrigger id="call-time" className="h-11">
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (9am - 12pm)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (12pm - 3pm)</SelectItem>
                    <SelectItem value="evening">Evening (3pm - 6pm)</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="call-timezone">Timezone *</Label>
                <Select
                  required
                  value={callFormData.timezone}
                  onValueChange={(value) => setCallFormData({ ...callFormData, timezone: value })}
                >
                  <SelectTrigger id="call-timezone" className="h-11">
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EST">Eastern (EST)</SelectItem>
                    <SelectItem value="CST">Central (CST)</SelectItem>
                    <SelectItem value="MST">Mountain (MST)</SelectItem>
                    <SelectItem value="PST">Pacific (PST)</SelectItem>
                    <SelectItem value="GMT">GMT</SelectItem>
                    <SelectItem value="CET">Central Europe (CET)</SelectItem>
                    <SelectItem value="AEST">Australian Eastern (AEST)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="call-message">What would you like to discuss?</Label>
              <Textarea
                id="call-message"
                value={callFormData.message}
                onChange={(e) => setCallFormData({ ...callFormData, message: e.target.value })}
                placeholder="Tell us about your business goals, challenges, or questions..."
                rows={4}
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsCallModalOpen(false)}
                className="flex-1"
                disabled={isCallSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isCallSubmitting}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white"
              >
                {isCallSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Calendar className="w-4 h-4 mr-2" />
                    Request Call
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GetSupportPage;